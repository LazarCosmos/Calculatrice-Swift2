//
//  LogView.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-09.
//

import UIKit

class LogView: UIView {
    
   @IBOutlet private var label: UILabel!
    
    
    @IBOutlet private var icon: UIImageView!
    enum Style{
        case began, changed, ended
    }
    var style : Style = .began{
        didSet{
            setStyle(style)
        }
    }
    
    private func setStyle(_ style : Style){
        switch style{
        case .began:
            
            /*backgroundColor = UIColor(_colorLiteralRed: 200/255.0, green: 236/255.0, blue: 160/255.0, alpha: 1)*/
            icon.image = UIImage(named:"Icon Correct")
            icon.isHidden = false
        case .changed:
        
           backgroundColor = UIColor(_colorLiteralRed: 243/255.0, green: 135/255.0, blue: 148/255.0, alpha: 1)
            icon.image = UIImage(named:"Icon Error")
            icon.isHidden = false
        case .ended:
           /* backgroundColor = UIColor.lightGray*/
            backgroundColor = UIColor.systemOrange
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.icon.isHidden = true}
        }
    }
    
    var title = ""{
        didSet {
            label.text = title
        }
    }
}

