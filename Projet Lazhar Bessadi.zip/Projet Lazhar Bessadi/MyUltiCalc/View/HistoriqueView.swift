//
//  HistoriqueView.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-05.
//

import UIKit

class HistoriqueView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
