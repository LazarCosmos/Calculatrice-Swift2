//
//  DynamiqueView.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-07.
//

import UIKit



// Source du code tutoriel sur les animations basiques : https://www.youtube.com/watch?v=u2hxeXuFL78&ab_channel=D%C3%A9veloppeurLibr

extension UIButton {
    
    func pulsate() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.2
        pulse.fromValue = 0.6
        pulse.toValue = 1.5
        pulse.autoreverses = false
        pulse.repeatCount = 0
        pulse.initialVelocity = 0.5
       
        layer.add(pulse, forKey: nil)
    }
   
}

