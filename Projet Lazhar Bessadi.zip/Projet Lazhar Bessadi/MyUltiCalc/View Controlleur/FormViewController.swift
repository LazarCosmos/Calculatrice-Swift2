//
//  FormViewController.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-08-09.
//

import UIKit

class FormViewController: UIViewController {
    override func viewDidLoad() {
        passewordTextField.isSecureTextEntry = true
        confirmPassewordTextField.isSecureTextEntry = true
    }
    var users: [String: String] = [:]
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passewordTextField: UITextField!
    @IBOutlet weak var confirmPassewordTextField: UITextField!
    
    @IBOutlet weak var professionPickerView: UIPickerView!
    
    @IBOutlet weak var usageSegmentControl: UISegmentedControl!
    
    @IBOutlet weak var notificationSwich: UISwitch!
    
    @IBAction func dismissKeybord(_ sender: UITapGestureRecognizer) {
        nameTextField.resignFirstResponder()
        firstNameTextField.resignFirstResponder()
        emailTextField.resignFirstResponder()
        passewordTextField.resignFirstResponder()
        confirmPassewordTextField.resignFirstResponder()
        
    }
    
    @IBAction func validate(_ sender: UIButton) {
        let newUser = createUserObject()
                
                if let newUser = newUser {
                    checkUserStatus(newUser)
                    
                    let _: [String: String] = [
                        newUser.email: newUser.password
                    ]
                    
                    
                    
                    print(users)
                    
                    performSegue(withIdentifier: "segueToSuccess", sender: newUser)
                } else {
                    
                    showAlert(with: "Erreur", message: "La création de l'utilisateur a échoué.")
                }
            }
            
            func checkUserStatus(_ user: User) {
                switch user.status {
                case .accepted: users.updateValue(user.password, forKey: user.email)

                case .rejected(let error):
                    let alert: UIAlertController = UIAlertController(title: "Erreur", message: error, preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alert.addAction(okAction)
                    present(alert, animated: true, completion: nil)
                }
            }
            
            func createUserObject() -> User? {
                let name = nameTextField.text ?? ""
                let firstName = firstNameTextField.text ?? ""
                let email = emailTextField.text ?? ""
                let password = passewordTextField.text ?? ""
                let confirmPassword = confirmPassewordTextField.text ?? ""
                let notification = notificationSwich.isOn
                
                
                if password != confirmPassword {
                    showAlert(with: "Erreur", message: "Les mots de passe ne sont pas identiques.")
                    return nil
                }
                
                var usage: String
                if usageSegmentControl.selectedSegmentIndex == 0 {
                    usage = "Personnel"
                } else if usageSegmentControl.selectedSegmentIndex == 1 {
                    usage = "Etude"
                } else {
                    usage = "Professionnel"
                }
                
                let professionIndex = professionPickerView.selectedRow(inComponent: 0)
                let profession = professions[professionIndex]
                
                return User(name: name, firstName: firstName, email: email, password: password, notification: notification, usage: usage, profession: profession)
            }
            
            private func showAlert(with title: String, message: String) {
                let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
            }

            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if segue.identifier == "segueToSuccess" {
                    if let successVC = segue.destination as? SuccessViewController {
                        let user = sender as? User
                        successVC.user = user
                    }
                }
            }
        }

        extension FormViewController: UIPickerViewDataSource {
            func numberOfComponents(in pickerView: UIPickerView) -> Int {
                return 1
            }
            
            func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
                return professions.count
            }
        }

        extension FormViewController: UIPickerViewDelegate {
            func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
                return professions[row]
            }
        }

        extension FormViewController: UITextFieldDelegate {
            func textFieldShouldReturn(_ textField: UITextField) -> Bool {
                textField.resignFirstResponder()
                return true
            }
        }
