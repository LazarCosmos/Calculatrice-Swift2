import UIKit

class SuccessViewController: UIViewController {
    var user: User!

    @IBOutlet weak var label: UILabel!
    
    /*@IBAction func retourConnectButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "retourConnectSegue", sender: self)
           }
           
           override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
               if segue.identifier == "retourConnectSegue" {
                   if let destinationVC = segue.destination as? ConnectViewController  {
                       // Effectuez des opérations supplémentaires si nécessaire
                   }
               }
           }*/
           
           override func viewDidLoad() {
               super.viewDidLoad()
               setTextLabel()
           }

           private func setTextLabel() {
               guard let user = user else {
                   print("Erreur: L'utilisateur n'est pas défini.")
                   return
               }
               
               let name = user.name
           
               label.text = """
               Bienvenue à \(name)! Nous aimons les \(user.profession.lowercased())s.\nVous avez bien précisé que c'est pour un usage \(user.usage.lowercased()).
               Pour les notifications, vous avez choisi \(user.notification).
               """
           }
       }
