//
//  Dynamiaue.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-06.
//

import UIKit


    class LogView: UIView {
        
       
        enum Style{
            case clear, display, standard
        }
        var style : Style = .standard{
            didSet{
                setStyle(style)
            }
        }
        
        private func setStyle(_ style : Style){
            switch style{
            case .display:
                backgroundColor = UIColor(_colorLiteralRed: 200/255.0, green: 236/255.0, blue: 160/255.0, alpha: 1)
                icon.image = UIImage(named:"Icon Correct")
                icon.isHidden = false
            case .clear:
                backgroundColor = UIColor(_colorLiteralRed: 243/255.0, green: 135/255.0, blue: 148/255.0, alpha: 1)
                icon.image = UIImage(named:"Icon Error")
                icon.isHidden = false
            case .standard:
                backgroundColor = UIColor(_colorLiteralRed: 191/255.0, green: 196/255.0, blue: 201/255.0, alpha: 1)
                icon.isHidden = true
            }
        }
        
        var title = ""{
            didSet {
                label.text = title
            }
        }
    }
