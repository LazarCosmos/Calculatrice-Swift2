import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var calculOperation: UILabel!
    
    @IBOutlet weak var historiqueLabel: UITextView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var pulseButton: UIButton!
    @IBOutlet weak var monEgal: UIView!
    
    
    @IBOutlet weak var logView: LogView!
    
    var egalDeplacement: Int = 0
   
    
    override func viewDidLoad() {
        supprimeTout()
        setupButtons()
        calculOperation.text = "Vous pouvez tirer la touche egal"
        super.viewDidLoad()
        
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(monAction(_:)))
        monEgal.addGestureRecognizer(panGestureRecognizer)
        
    }
    
    @objc private func monAction(_ sender:
                                 UIPanGestureRecognizer) {
        switch sender.state {
        case.began :
            print(sender.state)
            monEgal.backgroundColor = UIColor.red
           // logView.title = "Quelque chose vient de bouger"
           // logView.style = .display
            
  
        case .changed:
            print(sender.state)
            transForm(gesture: sender)
            logView.title = "Quelque chose vient de bouger"
            logView.style = .changed
            supprimeTout()
            calculOperation.text = "Vous pouvez le relacher maintenant"
            
        case .ended:
            print(sender.state)
           logView.title = ""
            
            monEgal.backgroundColor = UIColor.green
            //Ajout la variable egalDeplacememt dans le tableau historique, on filtre le tableau et on compte le nombre de fois la variable se trouve dans le tableau
            egalDeplacement += 1
          
            
            animeMaVue()
            // Activation de propriete isHiden pour cacher le label calcuOperation
            calculOperation.isHidden = true
            // Desactivation de la propriote isHidden pour afficher le texte View historiqueLabel
            historiqueLabel.isHidden = false
            
           // logView.style = .clear
            historiqueLabel.text = "Nombre de fois où la touche égale est déplacée : \(egalDeplacement)\n" + M.historique.joined(separator: "\n")
            logView.style = .ended
            // Appel a la methode pour l'excution de la fonction supprimer tot apres 2 secondes
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                self.supprimeTout()
                
            }
            
       
  
        case .possible:
            print(sender.state)
        case .cancelled:
            print(sender.state)
        case .failed:
            print(sender.state)
        @unknown default:
            print(sender.state)
        }
    }
    
    private func animeMaVue() {
            UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping:  0.5, initialSpringVelocity:  0.5, animations: {
                self.monEgal.transform = .identity
                self.monEgal.backgroundColor = UIColor.systemOrange
               // logView.title = 
            })
        }

    
    private func transForm(gesture:
                           UIPanGestureRecognizer) {
        let gestureTranslation = gesture.translation(in: monEgal)
   
        monEgal.transform = CGAffineTransform(translationX: gestureTranslation.x , y: gestureTranslation.y)
        
    }
        
    
    
    let M = CalculatriceModel()
    
    
    
    func setupButtons() {
        pulseButton.layer.cornerRadius = 8
    }
    
    
    
    func supprimeTout() {
        M.operationCourante = ""
        M.resultat = 0.0
        calculOperation.text = "0"
        calculOperation.backgroundColor = UIColor.lightGray
        activityIndicator.isHidden = true
        historiqueLabel.isHidden = true
        calculOperation.isHidden = false
        //logView.style = .standard
        
    }
    
    func ajoutOperation(value: String) {
        M.operationCourante += value
        calculOperation.text = M.operationCourante
    }
    
    
    @IBAction func effaceToutTap(_ sender: UIButton) {
        supprimeTout()
        sender.pulsate()
        
    }
    
    @IBAction func supprimeTap(_ sender: UIButton) {
        if !M.operationCourante.isEmpty {
            M.operationCourante.removeLast()
            calculOperation.text = M.operationCourante
        }
        sender.pulsate()
    }
    
    func handleOperantTap(_ newOperant: String) {
        
        if !M.operationCourante.isEmpty {
            M.calcul()
            M.operationCourante = ""
        }
        M.operant = newOperant
        
    }
    
    @IBAction func pourcentageTap(_ sender: UIButton) {
        sender.pulsate()
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        PourcentageCalculator.pourcentage(M.operationCourante) { [weak self] resultat in
            guard let self = self else { return }
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
            if let resultat = resultat {
                self.calculOperation.text = String(resultat)
            } else {
                self.calculOperation.text = "Erreur!"
                calculOperation.backgroundColor = UIColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
            }
        }
    }
    
    
    @IBAction func power(_ sender: UIButton) {
        handleOperantTap("X^Y")
        sender.pulsate()
        
    }
    
    @IBAction func divisionTap(_ sender: UIButton) {
        handleOperantTap("/")
        sender.pulsate()
    }
    @IBAction func dismiss(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func multiplicationTap(_ sender: UIButton) {
        handleOperantTap("*")
        sender.pulsate()
    }
    
    @IBAction func soustractionTap(_ sender: UIButton) {
        handleOperantTap("-")
        sender.pulsate()
    }
    
    @IBAction func additionTap(_ sender: UIButton) {
        
        handleOperantTap("+")
        sender.pulsate()
    }
    
    @IBAction func egaliteTap(_ sender: UIButton) {
        sender.pulsate()
        if !M.operationCourante.isEmpty && M.operant != nil {
            M.calcul()
            
            M.operant = nil
            calculOperation.text = M.message
            if M.message == "Erreur!" {
                calculOperation.backgroundColor = UIColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
                
            }
            
        }
    }
    
    
    @IBAction func logTap(_ sender:UIButton) {
        sender.pulsate()
        
        historiqueLabel.text = M.historique.joined(separator: "\n")
        historiqueLabel.isHidden = false
        calculOperation.isHidden = true
        print(M.historique)
    }
    
    @IBAction func numericTap(_ sender: UIButton) {
        sender.pulsate()
        if let value = sender.titleLabel?.text {
            ajoutOperation(value: value)
        }
        sender.pulsate()
    }
    
    @IBAction func decimalTap(_ sender: UIButton) {
        sender.pulsate()
        if !M.operationCourante.contains(".") {
            ajoutOperation(value: ".")
        }
    }
    
    
    
    
   
    
    
   
   
}
    

    

