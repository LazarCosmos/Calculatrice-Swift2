//
//  WelcomViewController.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-08-10.
//

import UIKit

class WelcomViewController: UIViewController {

    @IBAction func unwindToWelcom(segue: UIStoryboardSegue) {
        
    }
}
