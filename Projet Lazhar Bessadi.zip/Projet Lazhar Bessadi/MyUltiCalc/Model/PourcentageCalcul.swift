//
//  PourcentageCalc.swift
//  MyUltiCalc
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-06.
//

import Foundation

struct PourcentageCalculator {
        static func pourcentage(_ operationCourante: String, completion: @escaping (Double?) -> Void) {
            // Simuler un délai asynchrone de 5 secondes
            DispatchQueue.global().asyncAfter(deadline: .now() + 5.0) {
                if let valeur = Double(operationCourante) {
                    let resultat = valeur / 100
                    // Appeler la completion handler avec le résultat
                    DispatchQueue.main.async {
                        completion(resultat)
                    }
                } else {
                    // En cas d'échec de conversion, passer nil à la completion handler
                    DispatchQueue.main.async {
                        completion(nil)
                    }
                }
            }
        }
    }


