import Foundation
class CalculatriceModel {
    
    var operationCourante: String = ""
    
    var operant: String? = nil
    var resultat: Double = 0.0
    var historique : [String] = []
    var message : String = ""
    
    
    func calcul() {
        if let valeurInput = Double(operationCourante) {
            if let operant = operant {
                let operandePrecedent = resultat
               
                switch operant {
                case "+":
                    additionSansNotif(valeurInput: valeurInput) { messageResultat, resultatAddition in
                         self.resultat = resultatAddition
                         self.message = messageResultat
                     }
                
                    
                case "-":
                    
                    resultat -= valeurInput
                    message = String(resultat)
                case "*":
                    resultat = multiplication(x: operandePrecedent, y: valeurInput)
                    message = String(resultat)
                case "X^Y":
                    resultat = pow(operandePrecedent, valeurInput)
                    message = String(resultat)
                case "/":
                    if valeurInput != 0.0 {
                        resultat /= valeurInput
                        message = String(resultat)
                    } else {
                        message = "Erreur!"
                        operationCourante = ""
                        return
                    }
                default:
                    break
                }
                func additionSansNotif(valeurInput: Double, completionHandler: @escaping (String, Double) -> Void) {
                    let resultatAddition = addition(x: resultat, y: valeurInput)
                    let messageResultat = "L'addition sans notification a bien été effectuée"
                    completionHandler(messageResultat, resultatAddition)
                }
                message = String(resultat)
                 operationCourante = ""
                
                // Ajouter à l'historique
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                let dateString = dateFormatter.string(from: Date())
                let historiqueEntree = "\(operandePrecedent) \(operant) \(valeurInput) = \(message) \nHeure de l'opération : \(dateString)"
                historique.append(historiqueEntree)
                
            } else {
                resultat = valeurInput
                message = String(resultat)
            }
        } else {
            message = "Erreur"
        }
       
        func multiplication(x: Double, y: Double)-> Double{
            return x * y
        }
        func addition(x: Double, y: Double) -> Double {
            return x + y
        }
        
                
    }
    
    
}
