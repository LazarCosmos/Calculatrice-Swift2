import Foundation

class User {
    var name: String
    var firstName: String
    var email: String
    var password: String
    var notification: Bool
    var usage: String
    var profession: String
    
    enum Status: Equatable {
        case accepted
        case rejected(String)
    }
    
    var status: Status {
        
        if name.isEmpty {
            return .rejected("Le nom ne doit pas être vide.")
        }
        
        if firstName.isEmpty {
            return .rejected("Le prénom ne doit pas être vide.")
        }
        
        if email.isEmpty {
            return .rejected("L'email ne doit pas être vide.")
        }
        
        if password.count < 6 {
            return .rejected("Le mot de passe est trop court.")
        }
        
        if usage.isEmpty {
            return .rejected("L'usage ne doit pas être vide.")
        }
        
        if profession.isEmpty {
            return .rejected("La profession ne doit pas être vide.")
        }
        
        return .accepted
    }
    
    init(name: String, firstName: String, email: String, password: String, notification: Bool, usage: String, profession: String) {
        self.name = name
        self.firstName = firstName
        self.email = email
        self.password = password
        self.notification = notification
        self.usage = usage
        self.profession = profession
    }
}
