//
//  UserTests.swift
//  MyUltiCalcTests
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-08-10.
//

import XCTest
@testable import MyUltiCalc

final class UserTests: XCTestCase {
    
    func testUserWithValidate(){
        let user = User(name: "Cacnaq", firstName: "Kabyle", email: "Cacnaq@kabyle.com", password: "1234567", notification: true, usage: "Etude", profession: "Medecin")
        XCTAssertEqual(user.status, .accepted)
    }
    func testUserWhithNameIsEmpty(){
        let user = User(name: "", firstName: "Kabyle", email: "Cacnaq@kabyle.com", password: "1234567", notification: true, usage: "Etude", profession: "Medecin")
        XCTAssertEqual(user.status, .rejected("Le nom ne doit pas être vide."))
    }
    func testUserWhithfirtNameIsEmpty(){
        let user = User(name: "Kabyle", firstName: "", email: "Cacnaq@kabyle.com", password: "1234567", notification: true, usage: "Etude", profession: "Medecin")
        XCTAssertEqual(user.status, .rejected("Le prénom ne doit pas être vide."))
    }
    func testWhithShortPassword(){
        let user = User(name: "Kabyle", firstName: "Cacnaq", email: "Cacnaq@kabyle.com", password: "12345", notification: true, usage: "Etude", profession: "Medecin")
        XCTAssertEqual(user.status, .rejected("Le mot de passe est trop court."))
    }
    func testWhithEmailIsEmpty(){
        let user = User(name: "Kabyle", firstName: "Cacnaq", email: "", password: "1234567", notification: true, usage: "Etude", profession: "Medecin")
        XCTAssertEqual(user.status, .rejected("L'email ne doit pas être vide."))
    }
    func testUserWithEmptyUsage() {
           let user = User(name: "Doe", firstName: "John", email: "john.doe@example.com", password: "securepassword", notification: true, usage: "", profession: "Developer")
        XCTAssertEqual(user.status, .rejected("L'usage ne doit pas être vide."))
    }
       
    
 func testUserWithEmptyProfession() {
        let user = User(name: "Doe", firstName: "John", email: "john.doe@example.com", password: "securepassword", notification: true, usage: "Personnel", profession: "")
     XCTAssertEqual(user.status, .rejected("La profession ne doit pas être vide."))
 }
}
