//
//  MyUltiCalcTests.swift
//  MyUltiCalcTests
//
//  Created by Lazhar Bessadi (Étudiant) on 2024-06-19.
//

import XCTest
@testable import MyUltiCalc
final class CalculTests: XCTestCase {
    let c = CalculatriceModel()
    
    
    
    
    
    func testAdditon() throws {
        //Arrange - preparation des donnees
        
        
        c.resultat = 5
        c.operationCourante = "10"
        c.operant = "+"
        c.calcul()
        
        XCTAssertEqual(c.resultat, 15)
        
    }
    func testMultiplication() throws {
        //Arrange
        c.resultat = 5
        c.operationCourante = "10"
        c.operant = "*"
        c.calcul()
        
        XCTAssertEqual(c.resultat, 50)
    }
    
    func testDivision () throws {
        c.resultat = 5
        c.operationCourante = "10"
        c.operant = "/"
        c.calcul()
        
        XCTAssertEqual(c.resultat, 0.5)
        XCTAssertEqual(c.message, "0.5")
        
        // Test devision par zero
        c.operationCourante = "0"
        c.calcul()
        XCTAssertEqual(c.message, "Erreur!")
        
    }
    
    func testHistorrique(){
        c.resultat = 5
        c.operationCourante = "10"
        c.operant = "+"
        c.calcul()
        
        XCTAssertFalse(c.historique.isEmpty)
        
    }
    
}
